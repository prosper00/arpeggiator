var class_auto_range =
[
    [ "AutoRange", "class_auto_range.html#a2f0638f4d8e2937080b67fc0614c8d6d", null ],
    [ "getMax", "class_auto_range.html#a4d27e5fe43f9b376b537def88ac74119", null ],
    [ "getMin", "class_auto_range.html#acd1dae6e6ffb288efc1618e2453ad5ef", null ],
    [ "getRange", "class_auto_range.html#a75c842b27ad3917be6d29e3d35b485f3", null ],
    [ "next", "class_auto_range.html#a788fca4c9f1e6699eb1990582015c0e3", null ]
];