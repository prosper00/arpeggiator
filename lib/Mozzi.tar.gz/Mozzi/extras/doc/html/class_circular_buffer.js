var class_circular_buffer =
[
    [ "CircularBuffer", "class_circular_buffer.html#a6789c0d6d73594fdd412a39445b5cd67", null ],
    [ "count", "class_circular_buffer.html#a04c3ee378688439c72760034e314eed3", null ],
    [ "isEmpty", "class_circular_buffer.html#ad0fa3e6277c9ab56d8bfc190b4271d41", null ],
    [ "isFull", "class_circular_buffer.html#a023321c0416562f30532d5c4848c383b", null ],
    [ "read", "class_circular_buffer.html#aa82ce86703d85248bfb037dc49d75dd3", null ],
    [ "write", "class_circular_buffer.html#a7f033a265c893ad6d949347fa797e9ab", null ]
];